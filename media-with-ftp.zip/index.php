<?php

/**
 * Plugin Name:       Media with FTP
 * Description:       Let's you upload images to ftp-server and remove the uploads in the WordPress Media Library.
 * Version:           1.0.0
 * Text Domain:       media-with-ftp
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

require_once plugin_dir_path( __FILE__ ) . 'cmb2/init.php';

define( 'MEDIA_WITH_FTP_VERSION', '1.0.0' );

require plugin_dir_path( __FILE__ ) . 'includes/class-media-with-ftp.php';

function run_media_with_ftp() {

	$plugin = new Media_With_Ftp();
	$plugin->run();

}
run_media_with_ftp();